# hack because backbone-rails gem was taken
require File.expand_path("../backbone-rails", __FILE__)