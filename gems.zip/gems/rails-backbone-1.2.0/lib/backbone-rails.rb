require 'rails'

module BackboneRails
  class Engine < Rails::Engine
  end
end
