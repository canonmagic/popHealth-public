### Version 2.29.4.1 (2022-07-25)
- Fixed version of assets included with 2.29.4

### Version 2.29.4 (2022-07-13)
- Updated Moment.js to 2.29.4

### Version 2.29.1.1 (2022-01-03)
- Fixed version of assets included with 2.29.1

### Version 2.29.1 (2021-12-20)
- Updated Moment.js to 2.29.1

### Version 2.20.1 (2018-03-22)
- Updated Moment.js to 2.20.1

### Version 2.17.1 (2017-01-15)
- Updated Moment.js to 2.17.1

### Version 2.15.1 (2016-09-22)
- Updated Moment.js to 2.15.1

### Version 2.11.1 (2016-04-12)
- Updated Moment.js to 2.11.1

### Version 2.11.0 (2016-01-08)
- Updated Moment.js to 2.11.0

### Version 2.10.6 (2015-10-06)
- Updated Moment.js to 2.10.6

### Version 2.10.3 (2015-06-09)
- Updated Moment.js to 2.10.3

### Version 2.10.2 (2015-04-23)
- Updated Moment.js to 2.10.2

### Version 2.9.0 (2015-01-12)
- Updated Moment.js to 2.9.0

### Version 2.8.4 (2015-01-12)
- Updated Moment.js to 2.8.4

### Version 2.8.3 (2014-09-11)
- Updated Moment.js to 2.8.3

### Version 2.8.2 (2014-09-11)
- Updated Moment.js to 2.8.2

### Version 2.8.1 (2014-08-06)
- Updated Moment.js to 2.8.1

### Version 2.8.0 (2014-08-06)
- Updated Moment.js to 2.8.0

### Version 2.7.0 (2014-06-13)
- Updated Moment.js to 2.7.0

### Version 2.6.0 (2014-04-25)
- Updated Moment.js to 2.6.0

### Version 2.5.1 (2014-01-28)
- Updated Moment.js to 2.5.1

### Version 2.5.0 (2014-01-05)
- Updated Moment.js to 2.5.0

### Version 2.4.0 (2013-11-13)
- Updated Moment.js to 2.4.0

### Version 2.2.1 (2013-09-19)
- Updated Moment.js to 2.2.1

### Version 2.1.0 (2013-07-20)
- Updated Moment.js to 2.1.0
- Updated localization files using compressed versions (ready for browser)

### Version 2.0.0.2 (2013-06-06)
- Fix localization files (thanks, eddloschi).

### Version 2.0.0.1 (2013-03-16)
- Actually update Moment.js to 2.0.0 (whoops).
- gem version 2.0.0 was yanked. It was only live for two minutes, so hopefully
  there was no harm done.

### Version 2.0.0 (2013-03-16)
- Upgrade Moment.js to 2.0.0
- Upgrade localization files to 2.0.0 tagged versions.
- Update Railties dependency to allow Rails 4
- Added automated tests

### Version 1.7.2 (2012-12-17)
- Upgrade Moment.js to 1.7.2
- Upgrade localization files to 1.7.2 tagged versions.

### Version 1.7.0 (2012-08-06)
- Upgrade Moment.js to 1.7.0
- Upgrade localization files to 1.7.0 tagged versions.

### Version 1.6.2 (2012-06-07)
- Upgraded Moment.js to 1.6.2
- Added localization files

### Version 1.5.0 (2012-03-30)
- Upgraded Moment.js to 1.5.0

### Version 1.4.0 (2012-02-09)
- Upgraded Moment.js to 1.4.0

### Version 1.3.0 (2012-01-10)
- Initial Release
