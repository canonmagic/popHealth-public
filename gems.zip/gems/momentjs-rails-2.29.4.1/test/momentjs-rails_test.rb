require 'test_helper'

class MomentjsRailsTest < ActiveSupport::TestCase
  test "truth" do
    assert_kind_of Module, Momentjs::Rails
  end
end
