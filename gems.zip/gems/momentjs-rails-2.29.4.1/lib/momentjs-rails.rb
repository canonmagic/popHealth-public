module Momentjs
  module Rails
    class Engine < ::Rails::Engine
      # Get rails to add app, lib, vendor to load path
    end
  end
end

